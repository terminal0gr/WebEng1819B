# IO.Swagger.Model.AffiliateSearchResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Meta** | [**AffiliateSearchMeta**](AffiliateSearchMeta.md) | Meta data about the results | 
**Results** | [**List&lt;AffiliateSearchResult&gt;**](AffiliateSearchResult.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

