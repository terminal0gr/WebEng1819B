# IO.Swagger.Model.ExtensiveTrainSearchResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Results** | [**List&lt;ExtensiveTrainSearchResult&gt;**](ExtensiveTrainSearchResult.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

