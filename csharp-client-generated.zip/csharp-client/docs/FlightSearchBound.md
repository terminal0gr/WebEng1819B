# IO.Swagger.Model.FlightSearchBound
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Flights** | [**List&lt;FlightSearchSegment&gt;**](FlightSearchSegment.md) |  | 
**Duration** | **string** | The duration of this bound, including layover time, expressed in the format hh:mm | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

