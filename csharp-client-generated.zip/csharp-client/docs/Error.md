# IO.Swagger.Model.Error
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | **int?** |  | 
**Message** | **string** |  | 
**MoreInfo** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

