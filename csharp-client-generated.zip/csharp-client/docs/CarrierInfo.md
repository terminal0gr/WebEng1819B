# IO.Swagger.Model.CarrierInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Logos** | [**Logos**](Logos.md) | Logos of the airline in a variety of sizes | 
**Name** | **string** | Display name of the airline | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

