# IO.Swagger.Model.Company
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CompanyCode** | **string** | The Amadeus 2-character company code of this provider. | 
**CompanyName** | **string** | The long name of the provider corresponding to the above code. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

