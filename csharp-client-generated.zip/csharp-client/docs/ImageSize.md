# IO.Swagger.Model.ImageSize
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Small** | [**Image**](Image.md) |  | [optional] 
**Medium** | [**Image**](Image.md) |  | [optional] 
**Large** | [**Image**](Image.md) |  | [optional] 
**Hd** | [**Image**](Image.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

