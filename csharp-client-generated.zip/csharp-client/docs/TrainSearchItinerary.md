# IO.Swagger.Model.TrainSearchItinerary
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Trains** | [**List&lt;TrainSearchSegment&gt;**](TrainSearchSegment.md) | The array of trains that will be required to complete the given itinerary. Since the cache currently only contains direct itineraries, there will be only one object in this array. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

