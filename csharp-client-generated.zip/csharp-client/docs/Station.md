# IO.Swagger.Model.Station
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StationCode** | **string** | ID of this rail station | 
**StationName** | **string** | Full name of this rail station. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

