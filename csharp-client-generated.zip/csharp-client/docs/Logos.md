# IO.Swagger.Model.Logos
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Small** | **string** | URL to logo of resolution 27x27px | [optional] 
**Medium** | **string** | URL to logo of resolution 60x60px | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

