# IO.Swagger.Model.AffiliateSearchMeta
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Carriers** | [**CarrierMeta**](CarrierMeta.md) | A map of meta information for each of the airlines involved in the response | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

